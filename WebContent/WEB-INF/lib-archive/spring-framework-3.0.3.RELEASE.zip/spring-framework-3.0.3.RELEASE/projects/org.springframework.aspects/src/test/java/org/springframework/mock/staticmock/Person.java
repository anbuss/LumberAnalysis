package org.springframework.mock.staticmock;

import javax.persistence.Entity;

@Entity
public class Person {
}

